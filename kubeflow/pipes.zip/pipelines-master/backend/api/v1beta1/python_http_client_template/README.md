This folder contains overrides to openapi-generator python http client templates.

Resources:
* Documentation for overriding templates: https://github.com/OpenAPITools/openapi-generator/tree/v4.3.1/modules/openapi-generator/src/main/resources/python.
* Original templates for the generator version we use: https://github.com/OpenAPITools/openapi-generator/tree/v4.3.1/modules/openapi-generator/src/main/resources/python
