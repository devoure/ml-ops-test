# ApiUrl

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pipeline_url** | **str** | URL of the pipeline definition or the pipeline version definition. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


