# ApiRunDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**run** | [**ApiRun**](ApiRun.md) |  | [optional] 
**pipeline_runtime** | [**ApiPipelineRuntime**](ApiPipelineRuntime.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


