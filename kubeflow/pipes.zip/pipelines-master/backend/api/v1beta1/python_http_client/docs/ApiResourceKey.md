# ApiResourceKey

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**ApiResourceType**](ApiResourceType.md) |  | [optional] 
**id** | **str** | The ID of the resource that referred to. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


