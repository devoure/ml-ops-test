# ApiReportRunMetricsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**run_id** | **str** | Required. The parent run ID of the metric. | [optional] 
**metrics** | [**list[ApiRunMetric]**](ApiRunMetric.md) | List of metrics to report. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


