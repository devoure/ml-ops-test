# ApiTrigger

Trigger defines what starts a pipeline run.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cron_schedule** | [**ApiCronSchedule**](ApiCronSchedule.md) |  | [optional] 
**periodic_schedule** | [**ApiPeriodicSchedule**](ApiPeriodicSchedule.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


