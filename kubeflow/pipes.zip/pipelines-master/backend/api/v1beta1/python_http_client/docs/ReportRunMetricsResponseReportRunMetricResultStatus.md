# ReportRunMetricsResponseReportRunMetricResultStatus

 - UNSPECIFIED: Default value if not present.  - OK: Indicates successful reporting.  - INVALID_ARGUMENT: Indicates that the payload of the metric is invalid.  - DUPLICATE_REPORTING: Indicates that the metric has been reported before.  - INTERNAL_ERROR: Indicates that something went wrong in the server.
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


